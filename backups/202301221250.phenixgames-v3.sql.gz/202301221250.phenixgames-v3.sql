-- MariaDB dump 10.19  Distrib 10.6.11-MariaDB, for Linux (x86_64)
--
-- Host: mysql    Database: phenixgames-v3
-- ------------------------------------------------------
-- Server version	5.7.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pg_characters`
--

DROP TABLE IF EXISTS `pg_characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pg_characters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `health` int(11) DEFAULT '100',
  `armour` int(11) DEFAULT '0',
  `last_pos` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `pg_characters_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `pg_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pg_characters`
--

LOCK TABLES `pg_characters` WRITE;
/*!40000 ALTER TABLE `pg_characters` DISABLE KEYS */;
INSERT INTO `pg_characters` VALUES (1,1,'ddddddddddd','ddddddddddd',100,0,'{\"x\": 86.61968231201172, \"y\": -1701.212890625, \"z\": 28.733566284179688}');
/*!40000 ALTER TABLE `pg_characters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pg_fuelstations`
--

DROP TABLE IF EXISTS `pg_fuelstations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pg_fuelstations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT '2',
  `fuel_stored` int(11) DEFAULT '1500',
  `fuel_buy_price` int(11) DEFAULT '0',
  `fuel_sell_price_b` int(11) DEFAULT '0',
  `fuel_sell_price_d` int(11) DEFAULT '0',
  `business_owner_id` int(11) DEFAULT '0',
  `business_profit_mp` int(11) DEFAULT '2',
  `pos` json DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Fuel Station XY',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pg_fuelstations`
--

LOCK TABLES `pg_fuelstations` WRITE;
/*!40000 ALTER TABLE `pg_fuelstations` DISABLE KEYS */;
INSERT INTO `pg_fuelstations` VALUES (1,2,1500,1,1,1,0,2,'\"-2096.231689453125, -320.1805114746094, 12.16186809539795\"','Name Not SET'),(2,2,1500,1,1,1,0,2,'\"-1437.87451171875, -276.6646423339844, 45.20764923095703\"','Name Not SET'),(3,2,1500,1,1,1,0,2,'\"265.10870361328125, -1259.649658203125, 28.142915725708\"','Name Not SET'),(4,2,1500,1,1,1,0,2,'\"-70.5535888671875, -1761.115478515625, 28.5340366363525\"','Name Not SET'),(5,2,1500,1,1,1,0,2,'\"819.5802612304688, -1028.227783203125, 25.40379524230957\"','Name Not SET'),(6,2,1500,1,1,1,0,2,'\"1208.087646484375, -1402.546630859375, 34.22418975830078\"','Name Not SET'),(7,2,1500,1,1,1,0,2,'\"1181.0179443359375, -330.87725830078125, 68.31642150878906\"','Name Not SET'),(8,2,1500,1,1,1,0,2,'\"620.7024536132812, 268.8438415527344, 102.0894775390625\"','Name Not SET'),(9,2,1500,1,1,1,0,2,'\"-723.3829956054688, -935.1769409179688, 18.213932037353516\"','Name Not SET'),(10,2,1500,1,1,1,0,2,'\"-2555.127197265625, 2334.345458984375, 32.078041076660156\"','Name Not SET'),(11,2,1500,1,1,1,0,2,'\"-92.83749389648438, 6417.72802734375, 30.48018455505371\"','Name Not SET'),(12,2,1500,1,1,1,0,2,'\"179.82217407226562, 6602.79345703125, 30.8681697845459\"','Name Not SET'),(13,2,1500,1,1,1,0,2,'\"1702.66064453125, 6420.0625, 31.637767791748047\"','Name Not SET'),(14,2,1500,1,1,1,0,2,'\"2004.308349609375, 3776.0361328125, 31.180767059326172\"','Name Not SET'),(15,2,1500,1,1,1,0,2,'\"-1799.5919189453125, 802.6926879882812, 137.65121459960938\"','Name Not SET'),(16,2,1500,1,1,1,0,2,'\"2678.701416015625, 3264.334228515625, 54.25672912597656\"','Name Not Set');
/*!40000 ALTER TABLE `pg_fuelstations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pg_fuelstations_marker`
--

DROP TABLE IF EXISTS `pg_fuelstations_marker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pg_fuelstations_marker` (
  `marker_id` int(11) NOT NULL AUTO_INCREMENT,
  `fuelstation_id` int(11) DEFAULT '0',
  `pos` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` float DEFAULT '5',
  `pgFuelstationId` int(11) DEFAULT NULL,
  PRIMARY KEY (`marker_id`),
  KEY `pgFuelstationId` (`pgFuelstationId`),
  CONSTRAINT `pg_fuelstations_marker_ibfk_1` FOREIGN KEY (`pgFuelstationId`) REFERENCES `pg_fuelstations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pg_fuelstations_marker`
--

LOCK TABLES `pg_fuelstations_marker` WRITE;
/*!40000 ALTER TABLE `pg_fuelstations_marker` DISABLE KEYS */;
INSERT INTO `pg_fuelstations_marker` VALUES (1,1,'-2088.719482421875, -327.52532958984375, 12.1',5,1),(2,1,' -2087.860107421875, -321.11541748046875, 12.1',5,1),(3,1,'-2087.17529296875, -312.86273193359375, 12.1',5,1),(4,1,' -2095.85205078125, -312.02020263671875, 12.1',5,1),(5,1,'-2096.8662109375, -320.28997802734375, 12.1',5,1),(6,1,' -2097.326416015625, -326.56317138671875, 12.1',5,1),(7,1,'-2105.908203125, -325.7210693359375, 12.1',5,1),(8,1,'-2105.2109375, -319.3222351074219, 12.1',5,1),(9,1,'-2104.612060546875, -311.1736755371094, 12.1',5,1),(10,2,'-1435.48388671875, -284.8983459472656, 45.4',5,2),(11,2,'-1429.3233642578125, -279.15826416015625, 45.4',5,2),(12,2,'-1438.031494140625, -268.7479248046875, 45.4',5,2),(13,2,'-1444.1319580078125, -274.4800109863281, 45.4',5,2),(14,3,'257.019287109375, -1253.5419921875, 28.2878475189209',5,3),(15,3,'257.0165100097656, -1261.2974853515625, 28.292953491210',5,3),(16,3,'257.0194396972656, -1268.6412353515625, 28.291019439697',5,3),(17,3,'264.4770202636719, -1268.1856689453125, 28.285774230957',5,3),(18,3,'265.6485290527344, -1261.325439453125, 28.2929477691650',5,3),(19,3,'265.6486511230469, -1253.809814453125, 28.2929325103759',5,3),(20,3,'274.4381103515625, -1253.61328125, 28.292945861816406',5,3),(21,3,'274.4244689941406, -1261.3138427734375, 28.292943954467',5,3),(22,3,'274.4245300292969, -1268.848388671875, 28.2919731140136',5,3),(23,4,'-61.54207992553711, -1760.5301513671875, 28.25951004028',5,4),(24,4,'-64.13148498535156, -1767.6470947265625, 28.25738716125',5,4),(25,4,'-71.7453384399414, -1765.93896484375, 28.52115821838379',5,4),(26,4,'-68.89092254638672, -1758.1839599609375, 28.53406333923',5,4),(27,4,'-76.63903045654297, -1755.0579833984375, 28.80983734130',5,4),(28,4,'-79.62542724609375, -1762.3548583984375, 28.79469871520',5,4),(29,5,'826.650146484375, -1026.0987548828125, 25.60308074951172',5,5),(30,5,'826.7279663085938, -1030.8363037109375, 25.60822105407715',5,5),(31,5,'819.5718994140625, -1031.41064453125, 25.404321670532227',5,5),(32,5,'818.4002075195312, -1025.9676513671875, 25.40343475341797',5,5),(33,5,'811.4053955078125, -1026.15478515625, 25.41167640686035',5,5),(34,5,'811.2819213867188, -1030.974609375, 25.400480270385742',5,5),(35,6,'1207.4771728515625, -1398.58056640625, 34.37740707397461',5,6),(36,6,'1204.5802001953125, -1401.4771728515625, 34.385520935058594',5,6),(37,6,'1209.6473388671875, -1406.4918212890625, 34.38521957397461',5,6),(38,6,'1212.520751953125, -1403.6181640625, 34.37619400024414',5,6),(39,7,'1178.6962890625, -338.9515380859375, 68.36003875732422',5,7),(40,7,'1186.252685546875, -337.69842529296875, 68.35582733154297',5,7),(41,7,'1184.8883056640625, -330.32818603515625, 68.26081085205078',5,7),(42,7,'1177.5660400390625, -331.5906066894531, 68.31694793701172',5,7),(43,7,'1175.7884521484375, -322.88568115234375, 68.34132385253906',5,7),(44,7,'1183.2469482421875, -321.6408996582031, 68.35301208496094',5,7),(45,8,'629.048583984375, 263.98028564453125, 102.2616195678711',5,8),(46,8,'629.0447998046875, 273.9710388183594, 102.25389862060547',5,8),(47,8,'621.5701904296875, 273.567626953125, 102.22160339355469',5,8),(48,8,'621.5761108398438, 263.81463623046875, 102.20919799804688',5,8),(49,8,'613.013427734375, 263.7915344238281, 102.13687133789062',5,8),(50,8,'613.0068359375, 273.9511413574219, 102.2669448852539',5,8),(51,9,'-715.9319458007812, -939.384765625, 18.209949493408203',5,9),(52,9,'-716.0150146484375, -932.4348754882812, 18.21392822265625',5,9),(53,9,'-723.4224853515625, -932.5189208984375, 18.208057403564453',5,9),(54,9,'-723.4212646484375, -939.456787109375, 18.203495025634766',5,9),(55,9,'-731.907958984375, -939.1605834960938, 18.171321868896484',5,9),(56,9,'-732.0656127929688, -932.6857299804688, 18.21395492553711',5,9),(57,10,'-2552.44580078125, 2333.77001953125, 32.244449615478516',5,10),(58,10,'-2558.483154296875, 2333.60595703125, 32.256675720214844',5,10),(59,10,'-2558.53076171875, 2340.75927734375, 32.232627868652344',5,10),(60,10,'-2552.156982421875, 2341.168212890625, 32.25579833984375',5,10),(61,10,'-2551.2236328125, 2327.94140625, 32.150394439697266',5,10),(62,10,'-2558.0576171875, 2327.289306640625, 32.25434112548828',5,10),(63,11,'-90.6957015991211, 6422.0595703125, 30.63750648498535',5,11),(64,11,'-96.4642333984375, 6416.2958984375, 30.6395206451416',5,11),(65,13,'1697.453857421875, 6417.81201171875, 31.764034271240234',5,13),(66,13,'1701.4764404296875, 6415.95166015625, 31.755958557128906',5,13),(67,13,'1705.38134765625, 6414.11962890625, 31.762042999267578',5,13),(68,12,'172.93472290039062, 6603.58154296875, 31.047393798828125',5,12),(69,12,'179.0832061767578, 6604.90966796875, 31.041072845458984',5,12),(70,12,'186.39474487304688, 6606.11083984375, 31.047401428222656',5,12),(71,14,'2009.7064208984375, 3776.16162109375, 31.403934478759766',5,14),(72,14,'2006.519287109375, 3774.357177734375, 31.403949737548828',5,14),(73,14,'2004.2933349609375, 3772.820068359375, 31.403949737548828',5,14),(74,14,'2001.8160400390625, 3771.420166015625, 31.403942108154297',5,14),(75,15,'-1796.6671142578125, 800.8064575195312, 137.6512451171875',5,15),(76,15,'-1801.93896484375, 806.787841796875, 137.64878845214844',5,15),(77,15,'-1796.377685546875, 811.57958984375, 137.6680450439453',5,15),(78,15,'-1791.2464599609375, 805.934326171875, 137.68492126464844',5,15),(79,15,'-1802.96875, 794.5437622070312, 137.6739044189453',5,15),(80,15,'-1808.2857666015625, 800.3460083007812, 137.67874145507812',5,15),(81,16,'2680.844970703125, 3265.544677734375, 54.40803146362305',5,16),(82,16,'2679.147216796875, 3261.921142578125, 54.40770721435547',5,16);
/*!40000 ALTER TABLE `pg_fuelstations_marker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pg_garages`
--

DROP TABLE IF EXISTS `pg_garages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pg_garages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pos` json DEFAULT NULL,
  `npc_rot` float DEFAULT NULL,
  `type` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pg_garages`
--

LOCK TABLES `pg_garages` WRITE;
/*!40000 ALTER TABLE `pg_garages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pg_garages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pg_houses`
--

DROP TABLE IF EXISTS `pg_houses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pg_houses` (
  `house_id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) DEFAULT NULL,
  `house_pos` json DEFAULT NULL,
  PRIMARY KEY (`house_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pg_houses`
--

LOCK TABLES `pg_houses` WRITE;
/*!40000 ALTER TABLE `pg_houses` DISABLE KEYS */;
/*!40000 ALTER TABLE `pg_houses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pg_items`
--

DROP TABLE IF EXISTS `pg_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pg_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isStackable` tinyint(1) DEFAULT '0',
  `maxCount` int(11) DEFAULT '1',
  `isDropable` tinyint(1) DEFAULT '0',
  `isSplitable` tinyint(1) DEFAULT '0',
  `isUsable` tinyint(1) DEFAULT '0',
  `isSellable` tinyint(1) DEFAULT '0',
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pg_items`
--

LOCK TABLES `pg_items` WRITE;
/*!40000 ALTER TABLE `pg_items` DISABLE KEYS */;
INSERT INTO `pg_items` VALUES (1,'Medikit',1,10,1,1,1,0,10),(2,'Weste',1,10,1,1,1,0,10);
/*!40000 ALTER TABLE `pg_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pg_money`
--

DROP TABLE IF EXISTS `pg_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pg_money` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) DEFAULT NULL,
  `hand_money` float DEFAULT '0',
  `bank_pin` int(11) DEFAULT NULL,
  `bank_money` float DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `pg_money_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `pg_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pg_money`
--

LOCK TABLES `pg_money` WRITE;
/*!40000 ALTER TABLE `pg_money` DISABLE KEYS */;
INSERT INTO `pg_money` VALUES (1,1,1500,NULL,0);
/*!40000 ALTER TABLE `pg_money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pg_permission_list`
--

DROP TABLE IF EXISTS `pg_permission_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pg_permission_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `root` tinyint(1) DEFAULT '0',
  `manage_rang` tinyint(1) DEFAULT '0',
  `manage_team` tinyint(1) DEFAULT '0',
  `manage_member_ext` tinyint(1) DEFAULT '0',
  `ban` tinyint(1) DEFAULT '0',
  `admin_menu` tinyint(1) DEFAULT '0',
  `manage_member` tinyint(1) DEFAULT '0',
  `godmode` tinyint(1) DEFAULT '0',
  `mute` tinyint(1) DEFAULT '0',
  `kick` tinyint(1) DEFAULT '0',
  `spawn_weapon` tinyint(1) DEFAULT '0',
  `tp_to` tinyint(1) DEFAULT '0',
  `car_spawn` tinyint(1) DEFAULT '0',
  `no_clip` tinyint(1) DEFAULT '0',
  `own_prefix` tinyint(1) DEFAULT '0',
  `isTeam` tinyint(1) DEFAULT '0',
  `tp` tinyint(1) DEFAULT '0',
  `heal` tinyint(1) DEFAULT '0',
  `revive` tinyint(1) DEFAULT '0',
  `permissionId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permissionId` (`permissionId`),
  CONSTRAINT `pg_permission_list_ibfk_1` FOREIGN KEY (`permissionId`) REFERENCES `pg_permission_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pg_permission_list`
--

LOCK TABLES `pg_permission_list` WRITE;
/*!40000 ALTER TABLE `pg_permission_list` DISABLE KEYS */;
INSERT INTO `pg_permission_list` VALUES (1,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1),(2,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,3),(3,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(4,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(5,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(6,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(7,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(8,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(9,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(10,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(11,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(12,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(13,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(14,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(15,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(16,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(17,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(18,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(19,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(20,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(21,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(22,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(23,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(24,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(25,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(26,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(27,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(28,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(29,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(30,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(31,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(32,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(33,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(34,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(35,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(36,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(37,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(38,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(39,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(40,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(41,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(42,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(43,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(44,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(45,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(46,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(47,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(48,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(49,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(50,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(51,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(52,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(53,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(54,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(55,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(56,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(57,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(58,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(59,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(60,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(61,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(62,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(63,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(64,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(65,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(66,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(67,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(68,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(69,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(70,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(71,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(72,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(73,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(74,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(75,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(76,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(77,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(78,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(79,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(80,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(81,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(82,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(83,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(84,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(85,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(86,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(87,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(88,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(89,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(90,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(91,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(92,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(93,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(94,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(95,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(96,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(97,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(98,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(99,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(100,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(101,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(102,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(103,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(104,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(105,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(106,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(107,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(108,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(109,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(110,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(111,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(112,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(113,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(114,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(115,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(116,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(117,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(118,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(119,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(120,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(121,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(122,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(123,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(124,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(125,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(126,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(127,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(128,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(129,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(130,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL),(131,0,1,1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,NULL),(132,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,NULL);
/*!40000 ALTER TABLE `pg_permission_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pg_permission_roles`
--

DROP TABLE IF EXISTS `pg_permission_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pg_permission_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rolename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pg_permission_roles`
--

LOCK TABLES `pg_permission_roles` WRITE;
/*!40000 ALTER TABLE `pg_permission_roles` DISABLE KEYS */;
INSERT INTO `pg_permission_roles` VALUES (1,'Projekt Leitung',10),(2,'Support',8),(3,'Administration',9),(4,'Mapper',4),(5,'Entwicklung',7),(6,'Designer',5),(7,'Content',6);
/*!40000 ALTER TABLE `pg_permission_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pg_punishments`
--

DROP TABLE IF EXISTS `pg_punishments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pg_punishments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) DEFAULT NULL,
  `banned` tinyint(1) DEFAULT '0',
  `muted` tinyint(1) DEFAULT '0',
  `till_date` datetime DEFAULT NULL,
  `admin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `punishment_id` int(11) DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `date_of_punsishment` datetime DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pg_punishments`
--

LOCK TABLES `pg_punishments` WRITE;
/*!40000 ALTER TABLE `pg_punishments` DISABLE KEYS */;
/*!40000 ALTER TABLE `pg_punishments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pg_user_inventory`
--

DROP TABLE IF EXISTS `pg_user_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pg_user_inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) DEFAULT NULL,
  `items` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `pg_user_inventory_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `pg_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pg_user_inventory`
--

LOCK TABLES `pg_user_inventory` WRITE;
/*!40000 ALTER TABLE `pg_user_inventory` DISABLE KEYS */;
INSERT INTO `pg_user_inventory` VALUES (1,1,'[]');
/*!40000 ALTER TABLE `pg_user_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pg_users`
--

DROP TABLE IF EXISTS `pg_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pg_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isTeam` tinyint(1) DEFAULT '0',
  `isAdmin` tinyint(1) DEFAULT '0',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roleId` int(11) DEFAULT NULL,
  `isMedia` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pg_users`
--

LOCK TABLES `pg_users` WRITE;
/*!40000 ALTER TABLE `pg_users` DISABLE KEYS */;
INSERT INTO `pg_users` VALUES (1,'Mittelblut9',0,1,'$2a$12$pw8IsG7dDYUDZ5Br5fiPr.vgNvE3k9GSoK1CX3JzzG8fJ2st9SYO.',10,0);
/*!40000 ALTER TABLE `pg_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pg_vehicles`
--

DROP TABLE IF EXISTS `pg_vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pg_vehicles` (
  `veh_id` int(11) NOT NULL AUTO_INCREMENT,
  `veh_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `veh_owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Staat',
  `veh_keys` json DEFAULT NULL,
  `veh_state` tinyint(1) DEFAULT '1',
  `veh_pos` json DEFAULT NULL,
  `veh_rot` float DEFAULT '0',
  `veh_prim` int(11) DEFAULT NULL,
  `veh_sec` int(11) DEFAULT NULL,
  `veh_fuel` float DEFAULT NULL,
  `veh_max` float DEFAULT '100',
  `veh_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'benzin',
  PRIMARY KEY (`veh_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pg_vehicles`
--

LOCK TABLES `pg_vehicles` WRITE;
/*!40000 ALTER TABLE `pg_vehicles` DISABLE KEYS */;
INSERT INTO `pg_vehicles` VALUES (1,'p1','Mittelblut9','[1]',1,'{\"x\": -378.82818603515625, \"y\": -1854.5706787109375, \"z\": 20.645082473754883}',-141.874,0,0,97.3204,NULL,'benzin'),(2,'p1','Mittelblut9','[1]',1,'{\"x\": 86.61968231201172, \"y\": -1701.212890625, \"z\": 28.733566284179688}',-135.468,0,0,96.4496,NULL,'benzin'),(3,'speed','Mittelblut9','[1]',1,'{\"x\": -319.9664611816406, \"y\": -1829.6038818359375, \"z\": 23.709190368652344}',41.5238,10,0,0,NULL,'benzin');
/*!40000 ALTER TABLE `pg_vehicles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-22 12:50:37
